import * as React from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Container from '@mui/material/Container';
import Home from './Components/Home';



export default function App() {
  return (
    <Container maxWidth="md" sx={{marginTop:10 }}>

    <Card sx={{ minWidth: 500 }}>
      <CardContent>
        <Home/>
      </CardContent>
    
    </Card>
    </Container>
  );
}
