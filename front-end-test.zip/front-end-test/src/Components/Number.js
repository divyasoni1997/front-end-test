import React from 'react'
import Text from './Text'

const Number = () => {
  return (
    <div><Text/></div>
  )
}

export default Number