import React, { useState } from "react";
import Stack from "@mui/material/Stack";
import TextField from "@mui/material/TextField";
import { Card, makeStyles } from "@material-ui/core";
import { Button, IconButton } from "@mui/material";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";
import RemoveCircleOutlineIcon from "@mui/icons-material/RemoveCircleOutline";

const useStyle = makeStyles((theme) => ({
  textBody: {
    display: "flex",
    alignItems: "center",
    padding:'20px',
    background: '#eee',
    margin: '10px 0 10px 15px'
 
  }
 
}));

export default function Text() {
  const handleAdd = () => {
    setInputFields([...inputFields, { placeholder: "", max: "", min: "", rows:'' }]);
  };

  const handleRemove = (index) => {
    const values = [...inputFields];
    values.splice(index, 1);
    setInputFields(values);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("inputFields", inputFields);
  };

  const handleChangeInput = (index, e) => {
    const values = [...inputFields];
    values[index][e.target.name] = e.target.value;
    setInputFields(values);
  };
  const Classes = useStyle();
  const [inputFields, setInputFields] = useState([
    { placeholder: "", max: "", min: "", rows:'' },
  ]);

  return (
    <>
      <Stack
        component="form"
        spacing={2}
        noValidate
        autoComplete="off"
      >
        <form className={Classes.root} onSubmit={handleSubmit}>
          {inputFields.map((inputFields, index) => (
            <div className={Classes.textBody} key={index}>
              <TextField
                label="Placeholder"
                id="filled-hidden-label-small"
                name="placeholder"
                variant="outlined"
                size="small"
                value={inputFields.placeholder}
                onChange={(e) => handleChangeInput(index, e)}
              />
              <TextField
                label="max"
                id="max"
                name="max"
                variant="outlined"
                size="small"
                value={inputFields.max}
                onChange={(e) => handleChangeInput(index, e)}
              />
              <TextField
                label="min"
                id="min"
                name="min"
                variant="outlined"
                size="small"
                value={inputFields.min}
                onChange={(e) => handleChangeInput(index, e)}
              />
               <TextField
                label="rows"
                id="rows"
                name="rows"
                variant="outlined"
                size="small"
                value={inputFields.rows}
                onChange={(e) => handleChangeInput(index, e)}
              />
              {index === 0 ? (
                ""
              ) : (
                <Button onClick={() => handleRemove(index)}>
                  <RemoveCircleOutlineIcon />
                </Button>
              )}
            </div>
          ))}
<div style={{display:'flex', justifyContent:'space-between'}}>
          <Button
            onClick={handleSubmit}
            variant="contained"
            color="primary"
            type="submit"
            style={{margin:'10px 20px'}}
          >
            Sends
          </Button>
          <IconButton>
        <Button onClick={() => handleAdd()}>
          <AddCircleOutlineIcon />
        </Button>
      </IconButton>
      </div>
        </form>
      </Stack>
    
    </>
  );
}
