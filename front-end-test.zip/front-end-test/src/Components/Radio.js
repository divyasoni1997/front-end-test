import React from 'react'
import Selects from './Selects'

const Radio = () => {
  return (
    <div><Selects/></div>
  )
}

export default Radio