

import * as React from 'react';
import './css/style.css'
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import TextField from '@mui/material/TextField';
import Text from './Text';
import Number from './Number';
import Selects from './Selects';
import Radio from './Radio';

const Home = () => {
    const [answer, setAnswer] = React.useState('');

    const handleChange = (event) => {
      setAnswer(event.target.value);
    };

  return (
    <div>
       <div className='question-title'><ArrowBackIcon/><h4>Add Question</h4></div>
      <FormControl variant="filled" sx={{ m: 2, minWidth: 800 }}>
      <TextField id="filled-basic" label="Question" variant="filled" />
      </FormControl>
      <FormControl variant="filled" sx={{ m: 2, minWidth: 800 }}>
      
        <InputLabel id="demo-simple-select-filled-label">Answer</InputLabel>
        <Select
          labelId="demo-simple-select-filled-label"
          id="demo-simple-select-filled"
          value={answer}
          onChange={handleChange}
        >
          
          <MenuItem value="">
                        <em>None</em>
                    </MenuItem>
         
         
          <MenuItem value={<Text/>}>Text</MenuItem>
          <MenuItem value={<Number/>}>Number</MenuItem>
          <MenuItem value={<Selects/>}>Select</MenuItem>
          <MenuItem value={<Text/>}>textarea</MenuItem>
          <MenuItem value={<Radio/>}>Radio</MenuItem>
          <MenuItem value={<Text/>}>Checkbox</MenuItem>
          <MenuItem value={<Number/>}>Slider</MenuItem>
        </Select>
      </FormControl>
      <div>{answer}</div>
      
    </div>
  );
  }
export default Home